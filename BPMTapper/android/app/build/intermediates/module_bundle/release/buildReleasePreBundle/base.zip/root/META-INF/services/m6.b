m6.b
